package cartes;

import java.util.ArrayList;
import java.util.Random;

public class Uno {
    private PaquetDeCartes talon;
    private PaquetDeCartes pioche;
    private ArrayList<Joueur> joueur;
    private int joueurActuel;
    private boolean sensHorraire ;

    public Uno(int i){
        initialiser(i);
    }

    //initialiser les paramètres du jeu
    public void initialiser(int nbjoueur){
        assert (nbjoueur > 1 ) : " erreur bug nbJoueur";
        this.creerJoueur(nbjoueur);
        this.distibuerCartes();
        this.choisirQuidistribue();
        this.choisirQuiJoue();
        this.sensHorraire = true;
    }

    /**
     * retourner le nombre des joueurs
     */
    public int nbJoueur() {
        return joueur.size();
    }

    /**
     * la fonction qui choisie le joueur suivant
     */
    public void choisirQuiJoue() {
        if (sensHorraire) {
            //si le joueur est le dernier
            if (joueurActuel == nbJoueur() - 1) {
                joueurActuel = 0;
            } else {
                joueurActuel += 1;
            }
        } else {
            if (joueurActuel == 0) {
                joueurActuel = this.nbJoueur() - 1;
            } else {
                joueurActuel -= 1;
            }
        }
    }
    
    /**
     * choisi qui va distribuer en premier
     */
    public void choisirQuidistribue() {
        //choisir au hasard le joueur qui distribue
        int distributeur = nbJoueur();
        Random R = new Random();
        int joueurQuiDistibue = R.nextInt(distributeur);
        //si le joueur est le dernier
        if(joueurQuiDistibue == nbJoueur() -1){
            joueurActuel = 0;
        }
        else{
            joueurActuel = joueurQuiDistibue + 1;
        }
    }

    /**
     * fonction qui distribue les cartes
     */
    public void distibuerCartes() {
        this.pioche = FabriqueCartes.getInstance().paquetStandart(this);
        this.talon = new PaquetDeCartes();
        this.pioche.melanger(); // mélange les cartes
        for(int i = 0; i < 7; i++){
            for(int j = 0; j < nbJoueur(); j++){
                Carte carte = this.pioche.piocher();
                Joueur jr = this.joueur.get(j);
                jr.reçoit(carte);
            }
        }
        this.talon.ajouter(this.pioche.piocher()); // ajouter la carte au talon
    }


    /**
     * fonction qui cree les joueurs
     * @param nbj
     */
    public void creerJoueur(int nbj) {
        this.joueur = new ArrayList<>(nbj);
        //ajouter le joueur amine
        this.joueur.add(new JoueurHumain(0, "Ludovic", this));
        //ajouter les Bots
        for(int i = 1; i < nbj; i++){
            this.joueur.add(new Bot(i, "Bot" + i, this ));
        }
    }
    
    /**
     * appliquer le changement du sens
     */
    public void EffetChangementDeSens(){
        sensHorraire = !sensHorraire;
    }

    /**
     * appliquer l'effet de passTonTour
     */
    public void EffetPassTonTour(){
        int nbjr = nbJoueur() - 1;
        if(sensHorraire){
            if(joueurActuel == nbjr ){
                joueurActuel = 0;
            }
            else {
                joueurActuel += joueurActuel;
            }
        }
        else {
            if (joueurActuel - 1 < 0 ){
                joueurActuel = nbjr;
            }
            else {
                joueurActuel = joueurActuel - 1;
            }
        }
    }

    /**
     * appliquer l'effet du plus2
     */
    public void EffetPlus2(){
        int nbjr = getNbJoueur();
        if(joueurActuel == nbjr ){
            joueurActuel = joueurActuel + 1;
        }
        for (int i = 0; i < 2; i++){
            Carte c = this.pioche.piocher();
            this.getJoeur(joueurActuel).getMain().ajouter(c);
        }
    }

    /**
     * appliquer l'effet du plus4
     */
    public void EffetPlus4(){
        int nbjr = nbJoueur() ;
        if(joueurActuel == nbjr){
            joueurActuel = joueurActuel + 1;
        }
        for (int i = 0; i < 4; i++){
            Carte c = this.pioche.piocher();
            this.getJoeur(joueurActuel).getMain().ajouter(c);
        }
    }
    
    /**
     * fonction qui retourne le sommet du talon
     */
    public Carte getSommetTalon(){
        return this.talon.getSommet();
    }

    /**
     * retourner le paquet du talon
     * @return
     */
    public PaquetDeCartes getTalon(){
        return this.talon;
    }

    /**
     * retourner le paquet pioche
     * @return
     */
    public PaquetDeCartes getPioche(){
        return this.pioche;
    }

    /**
     * retourne le joueur actuel
     * @return
     */
    public int getJoueurActuel(){
        return this.joueurActuel;
    }

    /**
     * retourner le nombre des joueurs
     * @return
     */
    public int getNbJoueur(){
        return this.nbJoueur();
    }

    /**
     * retourner le joueur dans l'indice entré
     * @param jr
     * @return
     */
    public Joueur getJoeur(int jr){
        return joueur.get(jr);
    }
}