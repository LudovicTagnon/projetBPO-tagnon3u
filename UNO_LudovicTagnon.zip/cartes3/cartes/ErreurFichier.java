package cartes;

public class ErreurFichier extends Exception {
        public ErreurFichier(String message) {
            super(message) ;
        }
}