package cartes;

/**
 * Class couleur
 * enumeration des couleurs
 */

public enum Couleur{
    BLEU("Bleu"),
    ROUGE("Rouge"),
    VERT("Vert"),
    JAUNE("Jaune");
    
    private String couleur;

    /**
     *  constructeur
     */
    Couleur(String nom){
        this.couleur = nom;
    }

    /**
     * retourner le nom de la couleur
     */
    public String getNom(){
        return this.couleur;
    }

    /**
     * retournet les nom des couleurs
     */
    public String toString(){
        return  getNom();
    }
}
