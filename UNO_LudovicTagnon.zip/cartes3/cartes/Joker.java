package cartes;

public class Joker extends Carte{

    public Joker(Uno u){
        super(u);
    }
    @Override
    public int getValeur(){
        return 50;
    }

    @Override
    public boolean peutEtreRecouverteParCarte(Carte c) {
        return  this.getValeur()==c.getValeur() ||  this.estDecouleurcompatibleAvec(c)  ;
    }

    @Override
    public boolean peutEtrePoseeSur(Chiffre c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus2 c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus4 c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(PasseTonTour c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(ChangementDeSens c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(Joker c){
        return true;
    }

    @Override
    public String getType(){
        return "Joker";
    }

    @Override
    public String toString() {
        return "Joker" + this.getCouleur();
    }
}