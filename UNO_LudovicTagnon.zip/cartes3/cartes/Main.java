package cartes;

public class Main {
    /**
     * fonction principale pour lancer le jeu
     * @param args
     * @throws CoupIncorrect
     */
    public static void main(String[] args) throws CoupIncorrect {
        Uno uno = new Uno(3);
        DialogueLigneDeCommande dlc = new DialogueLigneDeCommande(uno);
        dlc.Dialogue();
    }
}