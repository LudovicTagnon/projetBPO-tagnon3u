package cartes;

import java.util.Scanner;

public class DialogueLigneDeCommande {
    private Uno uno ;

    public DialogueLigneDeCommande(Uno uno) {
        this.uno = uno ;
    }
    /**
     * fonction qui va appliquer les effets
     */
    public void miseAJourEffet(){
        if(this.uno.getSommetTalon() instanceof ChangementDeSens){
            this.uno.EffetChangementDeSens();
        }

        if(this.uno.getSommetTalon() instanceof PasseTonTour){
            this.uno.EffetPassTonTour();
        }

        if(this.uno.getSommetTalon() instanceof Plus2){
            this.uno.EffetPlus2();
        }

        if(this.uno.getSommetTalon() instanceof Plus4){
            this.uno.EffetPlus4();
        }
    }
    
    /**
     * afficher le résultat de chaque joueur a la fin de la partie
     */
    public void Resultat(){
        int nbj = this.uno.getNbJoueur();
        for(int i = 0; i < nbj; i++){
            // afficher le joueur qui a gagné
            if (this.uno.getJoeur(i).getNbrCarteJoueur() == 0){
                System.out.println("\n Le joueur " + this.uno.getJoeur(i).toString() +  " à gagner ");
                //afficher le score de chaque joueur
                for (int j = 0; j < nbj; j++){
                    System.out.println("\n Le score du joueur "  + this.uno.getJoeur(j).toString() + " est : " + uno.getJoeur(j).getScore());
                }
            }
        }
    }



    public void Dialogue() throws CoupIncorrect
    {
        System.out.println("\n ///////////////////////////////////////////////\n" +
                "/////////// Bienvenu dans le jeu UNO ////////////\n" +
                "////////////////////////////////////////////////");
        boolean gameOver = false;
        while(!gameOver)
        {
    
    
            //verifier si la main des joueurs actuels est vide
            if(this.uno.getJoeur(uno.getJoueurActuel()).getMain().getNombreDeCartes() == 0)
            {
                gameOver = true;
            }
    
            //vérifie si le joueur actuel est le joueur humain
            if(this.uno.getJoueurActuel() == 0)
            {
                System.out.println("le joueur qui va jouer est : "
                        + this.uno.getJoeur(uno.getJoueurActuel()).toString()
                        + "\nla carte sur  le sommet : " + uno.getTalon().getSommet()
                        + "\nVotre paquet de cartes  : " + this.uno.getJoeur(uno.getJoueurActuel()).getMain().toString() +
                        "\n  ");
                System.out.println("Entrer la carte : ");
                Scanner s = new Scanner(System.in);
                String carte = s.nextLine();
                this.uno.getJoeur(uno.getJoueurActuel()).jouer(carte);
                //System.out.println("t'as joué la carte : " + uno.getJoueur(uno.getJoueurActuel()).getMain().getSommet());
            }
            else
            {
                System.out.println("le joueur qui va jouer est : "
                        + this.uno.getJoeur(uno.getJoueurActuel()).toString());
                this.uno.getJoeur(uno.getJoueurActuel()).jouer("");
            }
            if(this.uno.getJoeur(uno.getJoueurActuel()).getMain().getNombreDeCartes() == 0)
            {
                gameOver = true;
            }
            //choisir qui va joueur ensuite
            this.uno.choisirQuiJoue();
            //appliquer les effets des cartes
            this.miseAJourEffet();
        }
        //afficher les résultats si la partie est terminé
        this.Resultat();
    }
}