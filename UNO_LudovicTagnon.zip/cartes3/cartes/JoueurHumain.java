package cartes;

import java.util.Arrays;
import java.util.Scanner;

public class JoueurHumain extends Joueur{
    public JoueurHumain(int i, String marouane, Uno uno) {
        super(i,marouane,uno);
    }

    @Override
    /**
     * la fonction qui gere le coup
     */
    public void jouer(String coup) throws CoupIncorrect {
        try {
            Carte sommetTalon = this.getU().getTalon().getSommet();
            if (coup.equals("p")) {
                Carte crtPioche = this.getU().getPioche().piocher();
                if (sommetTalon.peutEtreRecouverteParCarte(crtPioche)) {
                    this.getU().getTalon().ajouterSommet(crtPioche);
                }
                else {
                    this.reçoit(crtPioche);
                }
            } else {
                Carte carteChoisie = carteChoisie(coup);
                if (sommetTalon.peutEtreRecouverteParCarte(carteChoisie)) {
                    this.getU().getTalon().ajouterSommet(carteChoisie);
                    this.getMain().enlever(carteChoisie);
                } else {
                    throw new CoupIncorrect("erreur coup incorrect");
                }
            }
        }
        catch(CoupIncorrect e){
            System.out.println("Entrer un nouveau coup");
            Scanner s = new Scanner(System.in);
            String carte = s.nextLine();
            this.jouer(carte);
            }
    }

    /**
     * gère la carte choisie par le joueur humaine
     * @param coup
     * @return carte choisie
     * @throws CoupIncorrect si la carte invalide
     */
    Carte carteChoisie(String coup) throws CoupIncorrect {
        try {
            assert (coup == null) : "error";
            String[] tsst = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};
            String[] tclr = {"v", "b", "r", "j"};

            int tailleCoup = coup.length();
            char clr = coup.charAt(coup.length() - 1); // si coup contient une couleur
            /**
             * si le coup contient un seul caractère
             */
            if (tailleCoup == 1) {
                PaquetDeCartes pioche = this.getU().getPioche();
                PaquetDeCartes talon = this.getU().getTalon();
                Carte sommet = this.getU().getTalon().getSommet();
                int char1 = Integer.parseInt(coup);
                if (Arrays.asList(tsst).contains(coup)) {
                    if (char1 < 0 || char1 > this.getMain().getNombreDeCartes()) {
                        throw new CoupIncorrect("coup faux l'indice n'existe pas");
                    } else {
                        return this.getMain().getCarte(char1 - 1);
                    }
                } else {
                    throw new CoupIncorrect("coup incorrect");
                }
            }
            /**
             * si le coup est contient deux caractères
             */
            else if (tailleCoup == 2) {
                String char1 = Character.toString(coup.charAt(0));
                String char2 = Character.toString(coup.charAt(1));
                int intCoup = Integer.parseInt(coup);

                assert (intCoup >= 0 && intCoup <= this.getMain().getNombreDeCartes()) : " erreur bug index invalide";
                assert (clr == 'v' || clr == 'j' || clr == 'r' || clr == 'b') : "erreur bug couleur invalide";

                if (Arrays.asList(tsst).contains(char1) || Arrays.asList(tsst).contains(char2)) {
                    return this.getMain().getCarte(intCoup - 1);

                } else if (Arrays.asList(tsst).contains(char1) && Arrays.asList(tsst).contains(char2)) {
                    Carte c = this.getMain().getCarte(intCoup - 1);
                    Couleur clrTmp = null;
                    switch (char2) {
                        case "v":
                            clrTmp = Couleur.VERT;
                            break;
                        case "j":
                            clrTmp = Couleur.JAUNE;
                            break;
                        case "r":
                            clrTmp = Couleur.ROUGE;
                            break;
                        case "b":
                            clrTmp = Couleur.BLEU;
                            break;
                    }
                    c.setCouleur(clrTmp);
                    return c;

                } else {
                    throw new CoupIncorrect(" coup faux ");
                }
            }

            /**
             * si le coup contient 3 caractères
             */
            else if (tailleCoup == 3) {
                String char1 = Character.toString(coup.charAt(0));
                String char2 = Character.toString(coup.charAt(1));
                String char3 = Character.toString(coup.charAt(2));
                int intCoup = Integer.parseInt(char1 + char3);

                if (Arrays.asList(tsst).contains(intCoup) && Arrays.asList(tsst).contains(char3)) {
                    Carte c = this.getMain().getCarte(intCoup - 1);
                    Couleur clrTmp = null;
                    switch (char3) {
                        case "v":
                            clrTmp = Couleur.VERT;
                            break;
                        case "j":
                            clrTmp = Couleur.JAUNE;
                            break;
                        case "r":
                            clrTmp = Couleur.ROUGE;
                            break;
                        case "b":
                            clrTmp = Couleur.BLEU;
                            break;
                    }
                    c.setCouleur(clrTmp);
                    return c;
                } else {
                    throw new CoupIncorrect("coup incorrect");
                }
            } else {
                throw new CoupIncorrect("erreur coup incorrect ");
            }
        } catch (Exception e) {
            System.out.println("Entrer un nouveau coup");
            Scanner s = new Scanner(System.in);
            String carte = s.nextLine();
            this.jouer(carte);
        }
        return null;
    }
}