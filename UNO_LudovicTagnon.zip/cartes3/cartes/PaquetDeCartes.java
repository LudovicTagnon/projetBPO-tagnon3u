package cartes;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.lang.StringBuilder;
import java.util.Scanner;

/**
 * paquet de cartes
 * @author Ludovic TAGNON
 */
public class PaquetDeCartes{

    private ArrayList<Carte> cartes;

    /**
     * Construction d'un paquet de cartes
     * */
    public PaquetDeCartes(){
        this.cartes = new ArrayList<>();
    }

    /**
     * @return Cartes dans le paquet
     */
    public ArrayList<Carte> getCarte(){
        return this.cartes;
    }
    
    public Carte getCarte(int index){
        return this.cartes.get(index);
    }

    /**
     * @return le paquet de carte en chaine de caractère
     */
    public String toString(){
        StringBuilder paquet = new StringBuilder();
        int a = 1;
        for(int i = 0;  i < this.getNombreDeCartes(); ++i ){
            paquet.append("<  ").append(a).append(" : ").append(cartes.get(i).toString()).append(" > ");
            a++;
        }
        return paquet.toString();
    }

    /**
     *
     * Ajoute les cartes au paquet
     * @param cartes Tableau de cartes
     */
    public void ajouter(Carte... cartes){
        Collections.addAll(this.cartes, cartes);
    }
    
    public void  ajouterSommet(Carte c){
        this.cartes.add(0 ,c);
    }
    
    /**
     * @return Nombre de cartes du paquet
     */
    public int getNombreDeCartes(){
        return this.cartes.size();
    }

    /**
     * Ajoute les cartes du paquet pdc au paquet
     * @param pdc Paquet de cartes
     */
    public void ajouter(PaquetDeCartes pdc){
        for (int i = 0; i < pdc.getNombreDeCartes(); ++i){
            this.cartes.add(pdc.getCarte().get(i));
        }
    }

    /**
     * fonction qui va enlever la carte placer en haut du paquet
     * @param carte
     */
    public void enlever(Carte carte){
        this.cartes.remove(carte);
    }
    
    /**
     * fonciton qui melange les cartes
     */
    public void melanger(){
        Random r = new Random();
        for (int i = 0; i < this.getNombreDeCartes(); ++i){
            int c = r.nextInt(this.getNombreDeCartes());
            Carte carte = this.cartes.get(0);
            enlever(carte);
            this.cartes.add(c, carte);
        }
    }

    /**
     * @return la premiere carte au sommet indice 0
     */
    public Carte getSommet(){
        return this.cartes.get(0);
    }

    /**
     * @return La carte piochée (retourne le premier element et l'enlever apres)
     */
    public Carte piocher(){
        Carte carte = getSommet();
        enlever(carte);
        return carte;
    }

    /**
     * fonction qui écrit les cartes d'un paquet de carte
     * @param nomDeFichier
     * @throws ErreurFichier
     */
    public void ecrire(String nomDeFichier) throws ErreurFichier {
        BufferedWriter flotFiltre;
        FileWriter flot;
        try {

            File file = new File(nomDeFichier);
            if (file.exists()) {
                throw new ErreurFichier(" Fichier existe deja");
            }
            flot = new FileWriter(nomDeFichier);
            flotFiltre = new BufferedWriter(flot);
    
            for(Carte carte : this.cartes)
            {
                flotFiltre.write(carte.getType());
                flotFiltre.newLine();
            }

            flotFiltre.close();

        } catch (ErreurFichier | IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void lire(String nomDeFichier) throws ErreurFichier {
        FileReader flot;
        BufferedReader flotFiltre;
        try {
            File file = new File(nomDeFichier);
            if (!file.exists()) {
                throw new ErreurFichier("fichier n'existe pas");
            }

            flot = new FileReader(nomDeFichier);
            flotFiltre = new BufferedReader(flot);
            Scanner filtre = new Scanner(flot);
            while(filtre.hasNext()) {
                filtre.next();
            }
        }
        catch (ErreurFichier | IOException e) {
            System.out.println(e.getMessage());
        }
    }
}