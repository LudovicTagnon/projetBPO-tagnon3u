package cartes;

public class PasseTonTour extends Carte{

    public PasseTonTour(Uno u, Couleur c){
        super(u, c);
    }

    @Override
    public int getValeur(){
        return 20;
    }

    @Override
    public boolean peutEtreRecouverteParCarte(Carte c) {
        return  this.getValeur()==c.getValeur() ||  this.estDecouleurcompatibleAvec(c) || c.peutEtrePoseeSur((PasseTonTour) this) ;
    }

    @Override
    public boolean peutEtrePoseeSur(Chiffre c) {
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus2 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus4 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Joker c) {
        return false;
    }


    @Override
    public boolean peutEtrePoseeSur(PasseTonTour c){
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(ChangementDeSens c) {
        return false;
    }


    @Override
    public String getType(){
        return "Passe ton tour";
    }

    @Override
    public String toString() {
        return " PasseTour "
                + this.getCouleur();
    }
}
