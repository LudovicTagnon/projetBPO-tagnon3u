package cartes;

public class FabriqueCartes {

    private static FabriqueCartes instance = new FabriqueCartes();

    public static FabriqueCartes getInstance() {
        return instance;
    }

    public PaquetDeCartes paquetStandart(Uno u) {
        PaquetDeCartes paquet = new PaquetDeCartes();
        int num = 0;
        /**
         * creation des cartes de valeurs avec 0
         */
        Chiffre c1 = new Chiffre(u, Couleur.JAUNE, 0);
        Chiffre c2 = new Chiffre(u, Couleur.BLEU, 0);
        Chiffre c3 = new Chiffre(u, Couleur.VERT, 0);
        Chiffre c4 = new Chiffre(u, Couleur.ROUGE, 0);
        paquet.ajouter(c1, c2, c3, c4);
        //ajouter les carte jaune
        for (int i = 0; i < 2; i++) {
            for (int j = 1; j <= 9; j++) {
                Chiffre c = new Chiffre(u, Couleur.JAUNE, j);
                paquet.ajouter(c);
            }
        }
        //ajouter les cartes Rouge
        for (int i = 0; i < 2; i++) {
            for (int j = 1; j <= 9; j++) {
                Chiffre c = new Chiffre(u, Couleur.ROUGE, j);
                paquet.ajouter(c);
            }
        }

        //ajouter les cartes Vert
        for (int i = 0; i < 2; i++) {
            for (int j = 1; j <= 9; j++) {
                Chiffre c = new Chiffre(u, Couleur.VERT, j);
                paquet.ajouter(c);
            }
        }
        //ajouter les cartes Bleu
        for (int i = 0; i < 2; i++) {
            for (int j = 1; j <= 9; j++) {
                Chiffre c = new Chiffre(u, Couleur.BLEU, j);
                paquet.ajouter(c);
            }
        }
        //ajouter les cartes plus 2
        for (int i = 0; i < 2; i++) {
            Plus2 cv = new Plus2(u, Couleur.VERT);
            Plus2 cj = new Plus2(u, Couleur.JAUNE);
            Plus2 cb = new Plus2(u, Couleur.BLEU);
            Plus2 cr = new Plus2(u, Couleur.ROUGE);
            paquet.ajouter(cv, cb, cr, cj);
        }
        //ajouter packet d'inversement de sens
        for (int i = 0; i < 2; i++) {
            ChangementDeSens sv = new ChangementDeSens(u, Couleur.VERT);
            ChangementDeSens sb = new ChangementDeSens(u, Couleur.BLEU);
            ChangementDeSens sr = new ChangementDeSens(u, Couleur.ROUGE);
            ChangementDeSens sj = new ChangementDeSens(u, Couleur.JAUNE);
            paquet.ajouter(sv, sj, sr, sb);
        }
        //ajout packet pass ton tour
        for (int i = 0; i < 2; i++) {
            PasseTonTour pv = new PasseTonTour(u, Couleur.VERT);
            PasseTonTour pb = new PasseTonTour(u, Couleur.BLEU);
            PasseTonTour pr = new PasseTonTour(u, Couleur.ROUGE);
            PasseTonTour pj = new PasseTonTour(u, Couleur.JAUNE);
            paquet.ajouter(pv, pb, pr, pj);
        }
        //ajout packet joker
        Joker j1 = new Joker(u);
        Joker j2 = new Joker(u);
        Joker j3 = new Joker(u);
        Joker j4 = new Joker(u);
        paquet.ajouter(j1, j2, j3, j4);

        //ajouter packer plus 4
        Plus4 pls1 = new Plus4(u);
        Plus4 pls2 = new Plus4(u);
        Plus4 pls3 = new Plus4(u);
        Plus4 pls4 = new Plus4(u);
        paquet.ajouter(pls1, pls2, pls3, pls4);
        
        return paquet;
    }
}