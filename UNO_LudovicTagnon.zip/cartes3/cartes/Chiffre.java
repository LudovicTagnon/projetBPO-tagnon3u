package cartes;

public class Chiffre extends Carte{
    private int valeur;

    public Chiffre(Uno u, Couleur c, int v){
        super(u,c);
        this.valeur = v;
    }

    @Override
    public int getValeur(){
        return this.valeur;
    }

    @Override
    public boolean peutEtreRecouverteParCarte(Carte c){
        return  this.estDecouleurcompatibleAvec(c)  || this.getValeur() == c.getValeur() ||c.peutEtrePoseeSur(this) ;
    }

    @Override
    public boolean peutEtrePoseeSur(Chiffre c){
        return  false;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus2 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus4 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Joker c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(PasseTonTour c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(ChangementDeSens c) {
        return false;
    }
    
    @Override
    public String getType(){
        return  "Chiffre";
    }

    @Override
    public String toString() {
        return "Chiffre "
                + this.valeur + " "
                + this.getCouleur();
    }
}
