package cartes;

public abstract class Carte {

    private Uno uno;
    private Couleur couleur ;

    public Carte(Uno u ){

        this.uno = u;
    }

    public Carte(Uno u , Couleur couleur) {
        assert (couleur != null) : "Erreur uno ou couleur vide";
        this.uno = u;
        this.couleur = couleur;
    }

    public abstract int getValeur();
    
    /**
     * verifier si la carte peut être recouverte par une autre carte
     * @param c
     * @return
     */
    public abstract boolean peutEtreRecouverteParCarte(Carte c);
    
    public Couleur getCouleur() {
        return couleur;
    }

    public void setCouleur(Couleur c) {
        this.couleur = c;
    }

    boolean estSansCouleur(){
        return  this.couleur == null;
    }

    /**
     * verifier si les cartes ont la meme couleur
     * @param c
     * @return
     */
    boolean estDecouleurcompatibleAvec(Carte c){
        return c.couleur == this.couleur;
    }

    public abstract boolean peutEtrePoseeSur(Chiffre c);

    public abstract boolean peutEtrePoseeSur(Plus2 c);

    public abstract boolean peutEtrePoseeSur(Plus4 c);

    public abstract boolean peutEtrePoseeSur(Joker c);

    public abstract boolean peutEtrePoseeSur(PasseTonTour c);

    public abstract boolean peutEtrePoseeSur(ChangementDeSens c);
    
    public abstract String getType();
    
    public abstract String toString();
}
