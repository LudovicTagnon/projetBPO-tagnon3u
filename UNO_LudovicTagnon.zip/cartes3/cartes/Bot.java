package cartes;

public class Bot extends Joueur {


    public Bot(int i, String s, Uno uno) {
        super(i, s, uno);

    }

    /**
     * fonction qui permet au bot de jouer
     * @param coup
     */
    @Override
    public void jouer(String coup) {
        boolean carteValide = false;
        PaquetDeCartes bootMain = this.getMain();
        PaquetDeCartes pioche = this.getU().getPioche();
        Carte talon = this.getU().getSommetTalon();
        int i = 0;
        while (!carteValide && i < bootMain.getNombreDeCartes()) {
            if (talon.peutEtreRecouverteParCarte(bootMain.getCarte(i))) {
                carteValide = true;
                }
            else {
                nouveauSommetMain();
                i++;
            }
        }

        if(carteValide){
            Carte c = bootMain.piocher();
            this.getU().getTalon().ajouterSommet(c);
        }
        else {
            if (this.getU().getSommetTalon().peutEtreRecouverteParCarte(pioche.piocher())) {
                this.getU().getTalon().ajouterSommet(pioche.piocher());
            } else {
                bootMain.ajouterSommet(pioche.piocher());
            }
        }
    }

}



