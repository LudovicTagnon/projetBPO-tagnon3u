package cartes;

public abstract class Joueur {
    
    private String nameJr;
    private Uno u;
    private PaquetDeCartes main;

    public Joueur (int i, String s, Uno uno) {
        this.nameJr = s;
        this.u = uno;
        this.main = new PaquetDeCartes();
    }

    public abstract void  jouer(String coup) throws CoupIncorrect;

    //ajouter la carte dans la main du joueur
    public void reçoit(Carte carte) {
        this.main.ajouterSommet(carte);
    }

    public PaquetDeCartes getMain(){
        return this.main;
    }

    public String toString() {
        return this.nameJr;
    }

    public int getNbrCarteJoueur(){
        return this.main.getNombreDeCartes();
    }

    public Carte piochePaquetJoueur(){
        return this.main.piocher();
    }

    public void nouveauSommetMain(){
        Carte c = piochePaquetJoueur();
        PaquetDeCartes pdc = new PaquetDeCartes();
        pdc.ajouter(c);
        pdc.ajouter(main);
        main = pdc;
    }

    public Uno getU() {
        return u;
    }

    public int getScore() {
        int score = 0;
        for(int i = 0 ; i < getNbrCarteJoueur(); i++){
            score = score + this.getMain().getCarte(i).getValeur();
        }
        return score;
    }
}