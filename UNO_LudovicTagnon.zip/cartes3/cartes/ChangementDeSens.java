package cartes;

public class ChangementDeSens extends Carte{
    public ChangementDeSens(Uno u, Couleur c){
        super(u, c);
    }

    @Override
    public int getValeur(){
        return 20;
    }

    @Override
    public boolean peutEtreRecouverteParCarte(Carte c) {
        return  this.getValeur()==c.getValeur() ||  this.estDecouleurcompatibleAvec(c)  ;
    }

    @Override
    public boolean peutEtrePoseeSur(Chiffre c) {
        return true;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus2 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Plus4 c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(Joker c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(PasseTonTour c) {
        return false;
    }

    @Override
    public boolean peutEtrePoseeSur(ChangementDeSens c){
        return true;
    }
    
    @Override
    public String getType(){
        return "ChangementDeSens" ;
    }

    @Override
    public String toString() {
        return " ChangementDeSens "
                + this.getCouleur();
    }
}
