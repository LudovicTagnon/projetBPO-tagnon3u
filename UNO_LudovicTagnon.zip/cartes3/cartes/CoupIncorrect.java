package cartes;

public class CoupIncorrect extends Exception{
    public CoupIncorrect(String msg){
        super(msg);
    }
}
